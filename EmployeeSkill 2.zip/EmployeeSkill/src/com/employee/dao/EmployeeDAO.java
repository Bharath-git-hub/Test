package com.employee.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.employee.model.Employee;


/**
 * EmployeeDAO.java This DAO class provides CRUD database operations for the
 * table Employees in the database.
 *
 */
public class EmployeeDAO {
	private String jdbcURL = "jdbc:mysql://localhost:3306/employeeDB?useSSL=false";
	private String jdbcEmployeename = "root";
	private String jdbcPassword = "root@123";

	private static final String INSERT_EMPLOYEES_SQL = "INSERT INTO emp_skill_info" + "  (name, department, exp_years, qualifications, certifications, tech_skills) VALUES "
			+ " (?, ?, ?, ?, ?, ?);";

	private static final String SELECT_EMPLOYEE_BY_ID = "select * from emp_skill_info where emp_no =?";
	private static final String SELECT_ALL_EMPLOYEES = "select * from emp_skill_info";
	private static final String DELETE_EMPLOYEES_SQL = "delete from emp_skill_info where emp_no = ?;";
	private static final String UPDATE_EMPLOYEES_SQL = "update emp_skill_info set department = ?,exp_years= ?, qualifications =?, certifications =?, tech_skills =? where emp_no = ?;";

	public EmployeeDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcEmployeename, jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertEmployee(Employee Employee) throws SQLException {
		System.out.println(INSERT_EMPLOYEES_SQL);
		// try-with-resource statement will auto close the connection.
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_EMPLOYEES_SQL)) {
			preparedStatement.setString(1, Employee.getName());
			preparedStatement.setString(2, Employee.getDepartment());
			preparedStatement.setInt(3, Employee.getExp_years());
			preparedStatement.setString(4, Employee.getQualifications());
			preparedStatement.setString(5, Employee.getCertifications());
			preparedStatement.setString(6, Employee.getTech_skills());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public Employee selectEmployee(int empNo) {
		Employee employee = null;
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_EMPLOYEE_BY_ID);) {
			preparedStatement.setInt(1, empNo);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String name = rs.getString("name");
				String department = rs.getString("department");
				int exp_years = rs.getInt("exp_years");
				String qualifications = rs.getString("qualifications");
				String certifications = rs.getString("certifications");
				String tech_skills = rs.getString("tech_skills");
				employee = new Employee(empNo, name, department, exp_years, qualifications, certifications, tech_skills);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return employee;
	}

	public List<Employee> selectAllEmployees() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Employee> employees = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_EMPLOYEES);) {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int empNo = rs.getInt("emp_no");
				String name = rs.getString("name");
				String department = rs.getString("department");
				int exp_years = rs.getInt("exp_years");
				String qualifications = rs.getString("qualifications");
				String certifications = rs.getString("certifications");
				String tech_skills = rs.getString("tech_skills");
				employees.add(new Employee(empNo, name, department, exp_years, qualifications, certifications, tech_skills));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return employees;
	}

	public boolean deleteEmployee(int empNo) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_EMPLOYEES_SQL);) {
			statement.setInt(1, empNo);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateEmployee(Employee Employee) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_EMPLOYEES_SQL);) {
			System.out.println("updated Employee:"+statement);
			statement.setString(1, Employee.getDepartment());
			statement.setInt(2, Employee.getExp_years());
			statement.setString(3, Employee.getQualifications());
			statement.setString(4, Employee.getCertifications());
			statement.setString(5, Employee.getTech_skills());
			statement.setInt(6, Employee.getEmpNo());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}

}