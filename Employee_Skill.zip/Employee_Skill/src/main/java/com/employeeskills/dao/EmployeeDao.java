package com.employeeskills.dao;


import com.employeeskills.Model.Employee;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

// interface extending crud repository
public interface EmployeeDao extends CrudRepository<Employee, Integer> {

	Optional<Employee> findByEmpname(String uname);

	List<Employee> findAllByEmpnameContainingIgnoreCase(String searchValue);

	List<Employee> findAllByYearsofexperienceContainingIgnoreCase(int searchValue);

	List<Employee> findAllByCertificationContainingIgnoreCase(String searchValue);

	List<Employee> findAllByQualificationContainingIgnoreCase(String searchValue);

	List<Employee> findAllByDepartmentContainingIgnoreCase(String searchValue);

	List<Employee> findAllByTechnicalskillsContainingIgnoreCase(String searchValue);

	List<Employee> findAllByEmployeeIDContainingIgnoreCase(int parseInt);

}
