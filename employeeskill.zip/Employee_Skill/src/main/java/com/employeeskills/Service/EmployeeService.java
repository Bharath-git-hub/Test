package com.employeeskills.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.employeeskills.constants.ApplicationConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeskills.Model.Employee;
import com.employeeskills.Model.UserObject;
import com.employeeskills.dao.EmployeeDao;
import com.employeeskills.dao.UserDao;
import com.employeeskills.dto.EmployeeDto;
import com.employeeskills.dto.UserDto;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

// employee service class
@Service
@Slf4j
public class EmployeeService {

    @Autowired
    private EmployeeDao employeeDao;
    
    @Autowired
    private UserDao userDao;

    // fetching all employees
    public List<Employee> getAllEmployees() {
        return (List<Employee>) employeeDao.findAll();
    }

    // fetching employee by id
    public Optional<Employee> getEmployee(int id) {
        return employeeDao.findById(id);
    }

    // inserting employee
    public Employee addEmployee(EmployeeDto empDto) {
        log.info("Successfully saved employee data into DB");
        Employee empEty = dtoMapper(empDto);
        return employeeDao.save(empEty);
    }

	private Employee dtoMapper(EmployeeDto empDto) {
		Employee empEty = new Employee();
        empEty.setCertification(empDto.getCertification());
        empEty.setDepartment(empDto.getDepartment());
        empEty.setEmployeeID(empDto.getEmployeeID());
        empEty.setEmpname(empDto.getEmpname());
        empEty.setQualification(empDto.getQualification());
        empEty.setTechnicalskills(empDto.getTechnicalskills());
        empEty.setYearsofexperience(empDto.getYearsofexperience());
		return empEty;
	}

    // updating employee by id
    public void updateEmployee(EmployeeDto empDto, int id) {
    	Employee empEty = dtoMapper(empDto);
        if (id == empEty.getEmployeeID()) {
            employeeDao.save(empEty);
        } else {
            log.error("Employee details not matching");
        }
    }

    // deleting employee by id
    public void deleteEmployeeByID(int id) {
        employeeDao.deleteById(id);
    }

	public Optional<UserObject> login(UserDto userDto) {
		UserObject lgn = new UserObject();
		lgn.setUname(userDto.getUname());
		lgn.setRole(userDto.getRole());
		lgn.setPsw(userDto.getPsw());
		if(lgn.getUname().equalsIgnoreCase("Jaga")) {
			lgn.setEmail("jagadish.jcb@gmail.com");
			lgn.setRole("ADMIN");
			return Optional.of(lgn);
		}
		Optional<UserObject> userObj = userDao.findById(lgn.getUname());//userObject(userDto.getUname());
		return userObj;
	}
	
	private List<UserObject> userObject(String name) {
		List<UserObject> UserObjectObj = new ArrayList<>();
		if(name.equalsIgnoreCase("Jaga")) {
			UserObject lgn = new UserObject();
			lgn.setUname("Jaga");
			lgn.setRole("ADMIN");
			lgn.setPsw("1234");
			UserObjectObj.add(lgn);
		}else if(name.equalsIgnoreCase("Bha")) {
			UserObject lgn = new UserObject();
			lgn.setUname("Bha");
			lgn.setRole("EMPLOYEE");
			lgn.setPsw("1234");
			UserObjectObj.add(lgn);
		}
		return UserObjectObj;
	}

	public void addUsers(UserDto userDto) {
		UserObject obj = new UserObject();
		obj.setEmail(userDto.getEmail());
		obj.setRole(userDto.getRole());
		obj.setUname(userDto.getUname());
		userDao.save(obj);
	}

	public Optional<Employee> getEmployeeByName(String uname) {
		return employeeDao.findByEmpname(uname);
	}

	public List<Employee> getAllEmployeesBySearch(String searchBy, String searchValue) {
		if(null != searchBy && !searchBy.isEmpty()) {
			switch(searchBy) {
				case "empNumber" : return employeeDao.findAllByEmployeeID(searchValue);
				case "empName" : return employeeDao.findAllByEmpnameContainingIgnoreCase(searchValue);
				case "empDepartment" : return employeeDao.findAllByDepartmentContainingIgnoreCase(searchValue);
				case "empYrOfExperience" : return employeeDao.findAllByYearsofexperience("%"+searchValue+"%");
				case "empQualification" : return employeeDao.findAllByQualificationContainingIgnoreCase(searchValue);
				case "empCertification" : return employeeDao.findAllByCertificationContainingIgnoreCase(searchValue);
				case "empTechnicalSkills" : return employeeDao.findAllByTechnicalskillsContainingIgnoreCase(searchValue);
				default : return searchByAll(searchValue);
			}
		}
		return null;
	}

	private List<Employee> searchByAll(String searchValue) {
		if (null != searchValue && !searchValue.trim().isEmpty()) {
			return employeeDao.findResultsBySearchValue("%"+searchValue+"%");
		}
		return (List<Employee>) employeeDao.findAll();
	}

	public UserObject getUser(String userName) {
		Optional<UserObject> user =  userDao.findById(userName);

		if(user.isPresent())
			return user.get();
		else
			return null;
	}

	public void updateUser(UserObject user) {
		user.setPsw(ApplicationConstants.PASSWORD);
		userDao.save(user);
	}

	public void updatePassWord(UserObject userObject) {
		userDao.save(userObject);
	}
}
