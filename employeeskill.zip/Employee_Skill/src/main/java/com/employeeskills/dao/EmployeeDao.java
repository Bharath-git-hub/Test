package com.employeeskills.dao;


import com.employeeskills.Model.Employee;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

// interface extending crud repository
public interface EmployeeDao extends CrudRepository<Employee, Integer> {

	Optional<Employee> findByEmpname(String uname);

	List<Employee> findAllByEmpnameContainingIgnoreCase(String searchValue);

	@Query(value = "SELECT * FROM EMP_SKILL_INFO1 WHERE CONCAT(EXP_YEARS, '') LIKE ?1", nativeQuery = true)
	List<Employee> findAllByYearsofexperience(String searchValue);

	List<Employee> findAllByCertificationContainingIgnoreCase(String searchValue);

	List<Employee> findAllByQualificationContainingIgnoreCase(String searchValue);

	List<Employee> findAllByDepartmentContainingIgnoreCase(String searchValue);

	List<Employee> findAllByTechnicalskillsContainingIgnoreCase(String searchValue);

	@Query(value = "SELECT * FROM EMP_SKILL_INFO1 WHERE CONCAT(EMP_NO, '') LIKE ?1", nativeQuery = true)
	List<Employee> findAllByEmployeeID(String searchValue);

	@Query(value = "SELECT * FROM EMP_SKILL_INFO1 WHERE CONCAT(EMP_NO, '') LIKE ?1 OR CONCAT(EXP_YEARS, '') LIKE ?1 OR NAME LIKE ?1 OR DEPARTMENT LIKE ?1" +
			" OR QUALIFICATIONS LIKE ?1 OR CERTIFICATIONS LIKE ?1 OR TECH_SKILLS LIKE ?1", nativeQuery = true)
	List<Employee> findResultsBySearchValue(String searchValue);

}
