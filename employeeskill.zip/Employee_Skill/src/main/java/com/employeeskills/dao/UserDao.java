package com.employeeskills.dao;

import org.springframework.data.repository.CrudRepository;

import com.employeeskills.Model.UserObject;

public interface UserDao extends CrudRepository<UserObject, String>{

}
