package com.employeeskills.employeeskills.EmployeeController;


import java.util.List;
import java.util.Optional;

import com.employeeskills.employeeskills.Model.Employee;
import com.employeeskills.employeeskills.Service.EmployeeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    // displaying list of all employees
    @GetMapping("/employees")
    public List<Employee> getAllEmployee(){
        log.info("Received request for getting all employees");
        List<Employee> empList = employeeService.getAllEmployees();
        log.info("Total num of employees = "+empList.size());
        return empList;
    }

    // displaying employee by id
    @GetMapping("/employees/{id}")
    public Optional<Employee> getEmployee(@PathVariable int id){
        log.info("Received request for getting employee with empid =" + id);
        return employeeService.getEmployee(id);
    }

    // inserting employee
    @PostMapping("/employees")
    public  Employee addEmployees(@RequestBody Employee employee){
        log.info("Received request for adding employee with emp Name =" + employee.getEmpname());
        return employeeService.addEmployee(employee);
    }

    //updating employee by id
    @PutMapping("/employees/{id}")
    public void updateEmployee(@RequestBody Employee e, @PathVariable int id){
        log.info("Received request for updating employee with empid =" + id);
        employeeService.updateEmployee(e, id);
        log.info("Successfully updated employee with empid = " + id);
    }

    // deleting employee by id
    @DeleteMapping("employees/{id}")
    public void deleteEmployeeByID(@RequestBody Employee e, @PathVariable int id){
        log.info("Received request for deleting employee with empid =" + id);
        employeeService.deleteEmployeeByID(id);
        log.info("Successfully deleted employee with empid =" + id);
    }
}

