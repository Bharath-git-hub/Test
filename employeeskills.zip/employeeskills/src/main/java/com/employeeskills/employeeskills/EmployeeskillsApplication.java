package com.employeeskills.employeeskills;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeskillsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeskillsApplication.class, args);
	}

}
